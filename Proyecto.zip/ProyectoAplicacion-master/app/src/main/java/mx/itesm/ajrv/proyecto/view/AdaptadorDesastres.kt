package mx.itesm.ajrv.proyecto.view

/*import mx.itesm.ajrv.proyecto.R

class AdaptadorDesastres(private val contexto: Context, var arrDesastres: Array<Pais>) :
    RecyclerView.Adapter<AdaptadorPais.RenglonPais>()
{
    // Se llama cada vez que se va a poblar un renglon
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RenglonPais {
        val vista = LayoutInflater.from(contexto).inflate(R.layout.renglon_pais, parent, false)
        return RenglonPais(vista)
    }
    // Para poblar un renglón (poner los datos en el renglón 'position')
    override fun onBindViewHolder(holder: RenglonPais, position: Int) {
        val pais = arrPaises[position]
        holder.set(pais)
    }
    // El número de renglones que tendra el recyclerview
    override fun getItemCount(): Int {
        return arrPaises.size
    }
    class RenglonPais (var renglonPais: View) : RecyclerView.ViewHolder(renglonPais)
    {
        fun set(pais: Pais) {
            renglonPais.findViewById<TextView>(R.id.tvPais).text = pais.nombre
            renglonPais.findViewById<TextView>(R.id.tvCasos).text = "${pais.casos}"
            renglonPais.findViewById<ImageView>(R.id.imgBandera).setImageResource(R.drawable.bandera)
            println(pais.info["flag"])  // Revisar si imprime el url de las banderas
            val url = pais.info["flag"]
            val imgBandera = renglonPais.findViewById<ImageView>(R.id.imgBandera)
            Glide.with(renglonPais.context).load(url).into(imgBandera)
        }
    }


}*/