package mx.itesm.ajrv.proyecto

data class Noticia(
    val titulo: String,
    val Descipcion: Int,
    val clase: String,
    val idImagen: Int,
    val urlImagen: String = "")
