package mx.itesm.ajrv.proyecto.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.itesm.ajrv.proyecto.R
import mx.itesm.ajrv.proyecto.databinding.ActivityIncendiosBinding

class incendios : AppCompatActivity() {
//    private lateinit var binding: ActivityIncendiosBinding
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
////        setContentView(R.layout.activity_main)
//        binding = ActivityIncendiosBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
////        registrarEventos()
//    }
}