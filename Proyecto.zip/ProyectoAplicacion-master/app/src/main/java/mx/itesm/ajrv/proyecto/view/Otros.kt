package mx.itesm.ajrv.proyecto.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.itesm.ajrv.proyecto.R

class otros : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otros)
    }
}