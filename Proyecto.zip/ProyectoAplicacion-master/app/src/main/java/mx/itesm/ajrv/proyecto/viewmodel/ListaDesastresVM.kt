package mx.itesm.ajrv.proyecto.viewmodel

import androidx.lifecycle.ViewModel

class ListaDesastresVM : ViewModel()
{

}